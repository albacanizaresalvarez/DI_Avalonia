using System;
using System.Collections.Generic;
using System.IO;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Notifications;
using Avalonia.Media;
using Avalonia.Media.Imaging;

namespace AvaloniaApplication2;

public partial class MainWindow : Window
{
    private List<Alumnos> listaAlumnos;
    private int indiceActual;
    bool esNuevoAlumno = false;
    bool modificacionActiva = false;
    private string rutaArchivo = "databank.data";
    static string rutafoto = "Fotos WForms\\Foto1.jpg";
    byte[] foto = File.ReadAllBytes(rutafoto);
    
    private Button btnAnterior, btnSiguiente, btnCargar, btnGuardar, btnNuevo, btnModificar, btnEliminar, btnConfirmar, btnCancelar;
    private Image imagenAlumno;
    private INotificationManager mensajesInfo;
    private CheckBox ckbox1;
    
    public MainWindow()
    {
        InitializeComponent();
        botones();
        BtnAnterior.IsEnabled = false;
        BtnCancelar.IsEnabled = false;
        BtnConfirmar.IsEnabled = false;
        byte[] fotoNueva;
            
        listaAlumnos = new List<Alumnos>();
        
        // Obtener la instancia de INotificationManager
        mensajesInfo = new WindowNotificationManager(this);
        
        //rutas modificadas
        string rutafoto1 = "Fotos WForms\\Foto1.jpg";
        string rutafoto2 = "Fotos WForms\\Foto2.jpg";
        string rutafoto3 = "Fotos WForms\\Foto3.jpg";
        string rutafoto4 = "Fotos WForms\\Foto4.jpg";
        string rutafoto5 = "Fotos WForms\\Foto5.jpg";
        
        byte[] foto1 = File.ReadAllBytes(rutafoto1);
        byte[] foto2 = File.ReadAllBytes(rutafoto2);
        byte[] foto3 = File.ReadAllBytes(rutafoto3);
        byte[] foto4 = File.ReadAllBytes(rutafoto4);
        byte[] foto5 = File.ReadAllBytes(rutafoto5);

        listaAlumnos.Add(new Alumnos("Juan", "Pérez", 20, 1.75f, 12345678, 'A', true, foto1));
        listaAlumnos.Add(new Alumnos("María", "Gómez", 22, 1.68f, 98765432, 'B', false, foto2));
        listaAlumnos.Add(new Alumnos("Carlos", "Rodríguez", 21, 1.80f, 55555555, 'C', true, foto3));
        listaAlumnos.Add(new Alumnos("Pepito", "Prieto", 24, 1.91f, 98234432, 'D', true, foto4));
        listaAlumnos.Add(new Alumnos("Alba", "Cañizares", 25, 1.83f, 55534555, 'E', false, foto5));

        indiceActual = 0; // Comenzar desde el primer alumno

        // Mostrar la información del primer alumno
        MostrarAlumnoActual();
        
    }
    
    
    //Asignación de cada elemento con la función que lo gestiona.
    public void botones()
    {
        imagenAlumno = this.FindControl<Image>("ImgFoto");
        btnAnterior = this.FindControl<Button>("BtnAnterior");
        btnSiguiente = this.FindControl<Button>("BtnSiguiente");
        btnCargar = this.FindControl<Button>("BtnCargar");
        btnGuardar = this.FindControl<Button>("BtnGuardar");
        btnNuevo = this.FindControl<Button>("BtnNuevo"); 
        btnModificar = this.FindControl<Button>("BtnModificar");
        btnEliminar = this.FindControl<Button>("BtnEliminar");
        btnConfirmar = this.FindControl<Button>("BtnConfirmar");
        btnCancelar = this.FindControl<Button>("BtnCancelar");
        ckbox1 = this.FindControl<CheckBox>("Ckbox");
        
        imagenAlumno.PointerPressed += ImagenAlumno_Click;
        btnAnterior.Click += btnAnterior_Click;
        btnSiguiente.Click += btnSiguiente_Click;
        btnCargar.Click += btnCargar_Click;
        btnGuardar.Click += btnGuardar_Click;
        btnNuevo.Click += btnCrear_Click;
        btnModificar.Click += btnModificar_Click;
        btnEliminar.Click += btnEliminar_Click;
        btnConfirmar.Click += btnConfirmar_Click;
        btnCancelar.Click += btnCancelar_Click;
        ckbox1.Click += ckBox_CheckedChanged;
    }
    
    
    //Funcion que muestra las ventanas de información
    private void MostrarMensaje(string mensaje, bool esError = false)
    {
        var mensajePopup = new TextBlock
        {
            Text = mensaje,
            FontSize = 14,
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(15),
        };

        var ventanaPopup = new Window
        {
            Content = mensajePopup,
            Title = esError ? "Error" : "Información",
            Width = 300,
            Height = 150,
            WindowStartupLocation = WindowStartupLocation.CenterScreen,
        };

        ventanaPopup.Show();
    }
    
    
    private bool MostrarAlumnoActual()
    {
        desactivarTextos();
        // Verificar si hay alumnos en la lista y si el índice está dentro de los límites
        if ((listaAlumnos.Count > 0) && (indiceActual >= 0) && (indiceActual < listaAlumnos.Count))
        {
            Alumnos alumnoActual = listaAlumnos[indiceActual];

            TxtNombre.Text = alumnoActual.Nombre;
            TxtApellido.Text = alumnoActual.Apellido1;
            TxtEdad.Text = alumnoActual.Edad.ToString();
            TxtAltura.Text = alumnoActual.Altura.ToString();
            TxtNumDni.Text = alumnoActual.Dni.ToString();
            TxtLetra.Text = alumnoActual.Letra.ToString();
            Ckbox.IsChecked = alumnoActual.EsNuevo;
            
            if (Ckbox.IsChecked == true) { TxtCkbox.Content = "Enhorabuena! Ya estas inscrito, \n las clases empezaran pronto"; }
            else { TxtCkbox.Content = "Esperamos que tuvieras buena experiencia";}
                
            TxtTotal.Text = listaAlumnos.Count.ToString();
            using (MemoryStream stream = new MemoryStream(alumnoActual.Foto))
            {
                // Crear un Bitmap desde el MemoryStream
                Bitmap bitmap = new Bitmap(stream);
                // Asignar el Bitmap al control de imagen
                imagenAlumno.Source = bitmap;
            }
           

            Console.WriteLine($"Mostrando alumno {indiceActual + 1} de {listaAlumnos.Count}");
            return true;
        }
        else
        {
            return false;
        }

    }
    
    
    // Permite elegir nueva foto de alumno
    private async void ImagenAlumno_Click(object sender, Avalonia.Input.PointerPressedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filters.Add(new FileDialogFilter() { Name = "Imágenes", Extensions = { "jpg", "jpeg", "png" } });

        string[] archivosSeleccionados = await openFileDialog.ShowAsync(this);

        if (archivosSeleccionados != null && archivosSeleccionados.Length > 0)
        {
            string rutaNuevaFoto = archivosSeleccionados[0];

            // Leer el nuevo archivo de imagen
            byte[] nuevaFoto = File.ReadAllBytes(rutaNuevaFoto);

            // Asignar la nueva foto al alumno actual
            if (indiceActual >= 0 && indiceActual < listaAlumnos.Count)
            {
                listaAlumnos[indiceActual].Foto = nuevaFoto;

                // Mostrar la nueva foto en el control de imagen
                using (MemoryStream stream = new MemoryStream(nuevaFoto))
                {
                    Bitmap bitmap = new Bitmap(stream);
                    imagenAlumno.Source = bitmap;
                }
            }
        }
    }
    
    

    private void btnAnterior_Click(object sender, EventArgs e)
    {
        if (indiceActual > 0)
        {
            indiceActual--;
            MostrarAlumnoActual();
        }

        // Desactivar el botón Anterior si no hay registros anteriores
        BtnAnterior.IsEnabled = (indiceActual > 0);

        // Activar el botón Siguiente después de hacer clic en Anterior
        BtnSiguiente.IsEnabled = true;

    }

    public void btnSiguiente_Click(object sender, EventArgs e)
    {
        if (indiceActual < listaAlumnos.Count - 1)
        {
            indiceActual++;
            MostrarAlumnoActual();
        }

        // Desactivar el botón Siguiente si no hay registros posteriores
        BtnSiguiente.IsEnabled = (indiceActual < listaAlumnos.Count - 1);

        // Activar el botón Anterior después de hacer clic en Siguiente
        BtnAnterior.IsEnabled = true;
    }
    
    private void ckBox_CheckedChanged(object sender, EventArgs e)
    {
        if ((bool)Ckbox.IsChecked!)
        {
            TxtCkbox.Content = " ¡Si! Enhorabuena! Ya estas inscrito, \n las clases empezaran pronto";
        }
        else
        {
            TxtCkbox.Content = "No, esperamos que tuvieras buena experiencia";
        }
    }



    private void btnCrear_Click(object sender, EventArgs e)
    {
        activarTextos();
        desactivarBotones();
        TxtNombre.Clear();
        TxtApellido.Clear();
        TxtEdad.Clear();
        TxtAltura.Clear();
        TxtNumDni.Clear();
        TxtLetra.Clear();
        esNuevoAlumno = true;
        MostrarMensaje($"Para cambiar la foto haz click sobre ella. Si no la cambias se te asignará una por defecto.");
    }
    
    private void btnConfirmar_Click(object sender, EventArgs e)
        {
            if (esNuevoAlumno == true)
            {
                //cuando estoy creando hago un nuevo alumno
                Alumnos alumnoNuevo = listaAlumnos[indiceActual];
                string nomNuevo = TxtNombre.Text;
                string apeNuevo = TxtApellido.Text;
                int edadNueva = int.Parse(TxtEdad.Text);
                float altNueva = float.Parse(TxtAltura.Text);
                int dniNuevo = int.Parse(TxtNumDni.Text);
                char letNueva = char.Parse(TxtLetra.Text);
                Boolean esNueNuevo = (bool)Ckbox.IsChecked;
                
                
                alumnoNuevo = new Alumnos(nomNuevo, apeNuevo, edadNueva, altNueva, dniNuevo, letNueva, esNueNuevo, foto);
                    
                listaAlumnos.Add(alumnoNuevo);
                indiceActual = listaAlumnos.Count - 1;
                MostrarAlumnoActual();
                esNuevoAlumno = false;
                MostrarMensaje($"Has creado un alumno nuevo");
                
            }
            

            if (modificacionActiva)
            {
                //Cuando modifico solo edito el actual
                Alumnos alumnoActual = listaAlumnos[indiceActual];
                alumnoActual.Nombre = TxtNombre.Text;
                alumnoActual.Apellido1 = TxtApellido.Text;
                alumnoActual.Edad = int.Parse(TxtEdad.Text);
                alumnoActual.Altura = float.Parse(TxtAltura.Text);
                alumnoActual.Dni = int.Parse(TxtNumDni.Text);
                alumnoActual.Letra = char.Parse(TxtLetra.Text);
                alumnoActual.EsNuevo = (bool)Ckbox.IsChecked;

                // Mostrar el alumno actualizado
                MostrarAlumnoActual();
                desactivarTextos();
                modificacionActiva = false;
                MostrarMensaje($"Se ha modificado");
            }
            activarBotones();
        }
    
    private void btnModificar_Click(object sender, EventArgs e)
    {
        modificacionActiva = true;
        activarTextos();
        desactivarBotones();
        MostrarMensaje($"Para cambiar la foto haz click sobre ella. Si no la cambias se te asignará una por defecto.");
    }
    
    private void btnEliminar_Click(object sender, EventArgs e)
    {
        // Verificar si hay alumnos en la lista
        if (listaAlumnos.Count > 0)
        {
            // Eliminar el alumno en la posición actual
            listaAlumnos.RemoveAt(indiceActual);

            // Ajustar el índice actual si es necesario
            if (indiceActual >= listaAlumnos.Count)
            {
                indiceActual = listaAlumnos.Count - 1;
            }

            // Mostrar la información actualizada
            if (listaAlumnos.Count > 0)
            {
                MostrarAlumnoActual();
            }
            else
            {
                MostrarMensaje($"No hay más alumnos en la lista.");
            }
        }
        else
        {
            MostrarMensaje($"No hay alumnos en la lista para eliminar");
        }

    }

    private void btnCancelar_Click(object sender, EventArgs e)
    {
        MostrarAlumnoActual();
        activarBotones();
        MostrarMensaje("Los cambios no han sido guardados.");
        
    }
    
    //leer desde fichero y mostrar en la vista
    private void btnCargar_Click(object sender, EventArgs e)
        {
            try
            {
                using (FileStream fs = new FileStream(rutaArchivo, FileMode.Open))
                using (BinaryReader reader = new BinaryReader(fs))
                {
                    listaAlumnos.Clear(); // Limpiar la lista antes de cargar nuevos datos

                    while (reader.BaseStream.Position < reader.BaseStream.Length)
                    {
                        // Leer propiedades individuales desde el archivo binario
                        string nombre = reader.ReadString();
                        string apellido1 = reader.ReadString();
                        int edad = reader.ReadInt32();
                        float altura = reader.ReadSingle();
                        int dni = reader.ReadInt32();
                        char letra = reader.ReadChar();
                        bool esNuevo = reader.ReadBoolean();
                        int fotoLength = reader.ReadInt32();
                        byte[] foto = reader.ReadBytes(fotoLength);

                        // Crear un nuevo alumno con los datos leídos y agregarlo a la lista
                        Alumnos alumno = new Alumnos(nombre, apellido1, edad, altura, dni, letra, esNuevo, foto);
                        listaAlumnos.Add(alumno);
                    }
                }

                indiceActual = 0;
                MostrarAlumnoActual();
                MostrarMensaje("Datos cargados correctamente.");
                
            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al cargar los datos: {ex.Message}");
            }
        }


    //Graba el fichero con la información de la vista
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                using (FileStream fs = new FileStream(rutaArchivo, FileMode.Create))
                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    foreach (var alumno in listaAlumnos)
                    {
                        // Guardar propiedades individuales en el archivo binario
                        writer.Write(alumno.Nombre);
                        writer.Write(alumno.Apellido1);
                        writer.Write(alumno.Edad);
                        writer.Write(alumno.Altura);
                        writer.Write(alumno.Dni);
                        writer.Write(alumno.Letra);
                        writer.Write(alumno.EsNuevo);
                        writer.Write(alumno.Foto.Length);
                        writer.Write(alumno.Foto);
                    }
                }
                MostrarMensaje("Datos guardados correctamente.");
                
            }
            catch (Exception ex)
            {
                MostrarMensaje($"Error al guardar los datos: {ex.Message}");
            }


        }
        

    //visibilidad de elementos.
    public void desactivarTextos()
    {
        TxtNombre.IsEnabled = false;
        TxtApellido.IsEnabled = false;
        TxtEdad.IsEnabled = false;
        TxtAltura.IsEnabled = false;
        TxtNumDni.IsEnabled= false;
        TxtLetra.IsEnabled = false;
        ImgFoto.IsEnabled = false;
        Ckbox.IsEnabled = false;
    }
    
    public void desactivarBotones()
    {
        BtnAnterior.IsEnabled = false;
        BtnSiguiente.IsEnabled = false;
        BtnCargar.IsEnabled = false;
        BtnGuardar.IsEnabled = false;
        BtnEliminar.IsEnabled = false;
        BtnModificar.IsEnabled = false;
        BtnNuevo.IsEnabled = false;
        BtnConfirmar.IsEnabled = true;
        BtnCancelar.IsEnabled = true;
    }
    public void activarBotones()
    {
        BtnAnterior.IsEnabled = true;
        BtnSiguiente.IsEnabled = true;
        BtnCargar.IsEnabled = true;
        BtnGuardar.IsEnabled = true;
        BtnEliminar.IsEnabled = true;
        BtnModificar.IsEnabled = true;
        BtnNuevo.IsEnabled = true;
        BtnConfirmar.IsEnabled = false;
        BtnCancelar.IsEnabled = false;
    }
    
    
    public void activarTextos()
    {
        TxtNombre.IsEnabled = true;
        TxtApellido.IsEnabled = true;
        TxtEdad.IsEnabled = true;
        TxtAltura.IsEnabled = true;
        TxtNumDni.IsEnabled= true;
        TxtLetra.IsEnabled = true;
        ImgFoto.IsEnabled = true;
        Ckbox.IsEnabled = true;
    }
    
    
    
}